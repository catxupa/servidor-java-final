package com.labanta.servidorlocal.controller;
import com.labanta.servidorlocal.model.ServicoModel;
import com.labanta.servidorlocal.dto.ServicoResponseDTO;
import com.labanta.servidorlocal.repository.ServicoRepository;
import com.labanta.servidorlocal.service.EmailService;
import com.labanta.servidorlocal.service.ExchangeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.labanta.servidorlocal.service.ServicoService;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1/servicos")
public class ServicoController {

    private final ServicoService servicoService;
    private final ExchangeService exchangeService;
    private final EmailService emailService;



    // Injeção do Serviço
    public ServicoController(ServicoService servicoService, ExchangeService exchangeService, EmailService emailService) {
        this.servicoService = servicoService;
        this.exchangeService = exchangeService;
        this.emailService = emailService;
        
    }



    @GetMapping
    public List<ServicoModel> listarTodos() {
        return servicoService.listarTodos();
    }

    @PostMapping
    public ServicoModel criarServico(
            @RequestBody ServicoModel novoServico) {
        return servicoService.save(novoServico);
    }

    @GetMapping("/desconto-aplicado")
    public List<ServicoResponseDTO> aplicarDesconto(
            @RequestParam Double percentagem) {

        // 1. Pedir a aplicacao do desconto à camada Service
      List<ServicoModel> servicosComDesconto =
              servicoService.aplicarDescontoEmAtivos(percentagem);

        // 2. Converter a lista de Entidades para Lista de DTOs (Filtro)
        List<ServicoResponseDTO> respostaDTO = new ArrayList<>();
        for (ServicoModel s : servicosComDesconto) {

            // Utiliza o precoComDesconto se existir, senão usa o preco original
            Double precoExibir = s.getPrecoComDesconto() != null ? s.getPrecoComDesconto() : s.getPreco();
            respostaDTO.add(new ServicoResponseDTO(s.getTitulo(), precoExibir));
        }

        // 3. Devolver lista filtrada
        return respostaDTO;
    }

    // novo metodo
    @GetMapping("/pesquisa")
    public ResponseEntity<List<ServicoModel>> pesquisarServicos(
            @RequestParam String titulo) {

        List<ServicoModel> resultado =
                servicoService.pesquisarServicos(titulo);

        return ResponseEntity.ok(resultado);
    }

    @GetMapping("/{id}")
    public ServicoModel buscarServicoPorId(
            @PathVariable Long id) {
        return servicoService.buscarServicoPorId(id);
    }

    @PostMapping("/{id}/orcamento")
    public String pedirOrcamento(
        @PathVariable Long id,
        @RequestParam String emailDestino,
        @RequestParam(defaultValue = "CVE") String moeda) {

        // 1. Ir à Base de Dados buscar o Serviço
        ServicoModel servico = servicoService.buscarServicoPorId(id);

        // 2. converter o preço
        Double precoConvertido = exchangeService.converterPreco(
                servico.getPreco(), moeda);


        // 3. Enviar o resultado para o Gmail do cliente
        emailService.enviarEmailOrcamento(
                emailDestino,
                servico.getTitulo(),
                precoConvertido,
                moeda
        );


        return "Orçamento calculado e enviado com sucesso para " + emailDestino + "!";
    }
}







