package com.labanta.servidorlocal.security;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;


@Configuration
public class SecurityConfig {

    private final CustomsAuthenticationEntrypoint customsAuthenticationEntrypoint;
    private final JwtAuthenticationFilter jwtAuthenticationFilter;


    public SecurityConfig(CustomsAuthenticationEntrypoint customsAuthenticationEntrypoint, JwtAuthenticationFilter jwtAthenticationFilter){
        this.customsAuthenticationEntrypoint = customsAuthenticationEntrypoint;
        this.jwtAuthenticationFilter = jwtAthenticationFilter;
    }




    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                .csrf(csrf -> csrf.disable())

                .exceptionHandling(  ex -> ex.authenticationEntryPoint(customsAuthenticationEntrypoint) )
                .exceptionHandling(ex -> ex.authenticationEntryPoint(customsAuthenticationEntrypoint))

                .authorizeHttpRequests(auth -> auth
                        // Permite login e registo (cobre /api/auth/login, /api/auth/register, /api/auth/login, /api/auth/registar)
                        .requestMatchers("/api/auth/**").permitAll()
                        // GET de serviços e pesquisa livres
                        .requestMatchers(HttpMethod.GET, "/api/v1/servicos/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/v1/servicos/*/orcamento").authenticated()

                        .anyRequest().authenticated()

        )
                .addFilterBefore(
                        jwtAuthenticationFilter,
                        org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class);



        return http.build();
    }
}
